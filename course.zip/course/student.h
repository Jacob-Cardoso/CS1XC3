  /**
   * @brief The struc containing students, first and last names, student id and grades.
   * 
   */
typedef struct _student 
{ 
  char first_name[50]; /** Student first name */
  char last_name[50];/** Student last name */
  char id[11];/** Student ID */
  double *grades; /** Students grades stored in a string. */
  int num_grades; /** Number of students grades. */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
