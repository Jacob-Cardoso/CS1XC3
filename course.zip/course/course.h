/**
 * @file course.h
 * @author Jacob Cardoso (cardoj3@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 /**
  * @brief Struct type named course, holds info on the name, code and total students stored in their respective variables.
  * 
  */
typedef struct _course 
{
  char name[100]; // Course name.
  char code[10]; // Course code.
  Student *students;
  int total_students; // Total number of students enrolled in the course.
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


